<h1 align="center">HPomb v2020.8</h1>
<h5 align="right">Created By Honey Pots</h5>
<p align="center">HPomb open-source project for SMS , Call &  Mail bombing available for   Window , Linux , MacOS And Android( Termux ) </p><br>
<img src="https://repository-images.githubusercontent.com/252939958/739b8c80-7695-11ea-9812-42157e3abf74" alt="look">

![platforms](https://img.shields.io/badge/Platforms-Windows%20%7C%20Android%20%7C%20Linux%20%7C%20MacOS-orange)
![Analisy](https://img.shields.io/badge/Version-2020.7-success)
![License: GPL v3](https://img.shields.io/badge/License%202.0-Apache-blue.svg)
<br>

## Features:

- Mail Bombing
- Call Bombing
- SMS Bombing
- Unlimited  and super-fast bombing (against abusing )
- International bombing available
- Community Support 
- fully Help 
- Automatic updating mechanism
- Easy to use 

## Requirements
* Python3
* requests 
* urllib3

## Usage:

Run these commands to Run HPomb

### > For Termux:

To use the HPomb type the following commands in Termux:
```
pkg install git
pkg install python
git clone https://github.com/HoneyPots0/HPomb.git
cd HPomb
chmod +x hpomb.py
pip3 install -r requirements.txt
python3 hpomb.py
```

### > For Linux:

To use the HBomb type the following commands in Linux terminal:
```
sudo apt-get install git
sudo apt-get install python3
git clone https://github.com/HoneyPots0/HPomb.git
cd HPomb
chmod +x hpomb.py
pip3 install -r requirements.txt
python3 hpbomb.py
```

### > For macOS:

To use the HPomb type the following commands in macOS terminal:
```
# Install Brew: 

/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"

# Install dependencys:

brew install git
brew install python3
sudo easy_install pip
sudo pip install --upgrade pip
git clone https://github.com/HoneyPots0/HPomb.git
cd HPomb
pip3 install -r requirements.txt
python3 hpomb.py
```
## Contact Me
* <b>YOUTUBE CHANNEL : https://www.youtube.com/c/honeypots0 </b>
* <b>INSTAGRAM I'D : https://www.instagram.com/honeypots0 </b>
